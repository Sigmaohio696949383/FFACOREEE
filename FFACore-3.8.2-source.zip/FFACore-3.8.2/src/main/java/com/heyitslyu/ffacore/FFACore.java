package com.heyitslyu.ffacore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.ChatColor;
import io.papermc.paper.event.player.AsyncChatEvent;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class FFACore extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private Connection db;
    private final Map<UUID, TeamData> teams = new HashMap<>();
    private final Map<UUID, UUID> invites = new ConcurrentHashMap<>();
    private final Map<String, String> colors;
    private final Map<UUID, String> selectedColors = new HashMap<>();

    public FFACore() { colors = new LinkedHashMap<>(); }

    @Override public void onEnable() {
        saveDefaultConfig();
        loadColors();
        try {
            db = DriverManager.getConnection("jdbc:sqlite:" + getDataFolder().toPath().resolve("furyfiedffa.db"));
            try (Statement s = db.createStatement()) {
                s.executeUpdate("CREATE TABLE IF NOT EXISTS stats(uuid TEXT PRIMARY KEY,name TEXT,kills INTEGER NOT NULL DEFAULT 0,deaths INTEGER NOT NULL DEFAULT 0)");
                s.executeUpdate("CREATE TABLE IF NOT EXISTS teams(id TEXT PRIMARY KEY,name TEXT UNIQUE,leader TEXT,color TEXT)");
                s.executeUpdate("CREATE TABLE IF NOT EXISTS members(uuid TEXT PRIMARY KEY,team_id TEXT)");
            }
            loadTeams();
        } catch (SQLException e) { getLogger().severe("Could not open FFACore database: " + e.getMessage()); getServer().getPluginManager().disablePlugin(this); return; }
        for (String cmd : List.of("team", "kd", "teamadmin", "kdadmin")) {
            Objects.requireNonNull(getCommand(cmd), "Missing command " + cmd).setExecutor(this);
            getCommand(cmd).setTabCompleter(this);
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        for (Player p : Bukkit.getOnlinePlayers()) refreshPlayer(p);
        getLogger().info("FuryfiedFFA 3.8.2 enabled. Target: Paper/Leaf 1.21.11.");
    }

    @Override public void onDisable() {
        try { if (db != null && !db.isClosed()) db.close(); } catch (SQLException ignored) {}
    }

    private void loadColors() {
        var section = getConfig().getConfigurationSection("team.colors");
        if (section != null) for (String key : section.getKeys(false)) colors.put(key.toLowerCase(Locale.ROOT), section.getString(key));
    }
    private void loadTeams() throws SQLException {
        try (Statement s = db.createStatement(); ResultSet r = s.executeQuery("SELECT id,name,leader,color FROM teams")) {
            while (r.next()) {
                TeamData t = new TeamData(UUID.fromString(r.getString(1)), r.getString(2), UUID.fromString(r.getString(3)), r.getString(4));
                teams.put(t.id, t);
            }
        }
        try (Statement s = db.createStatement(); ResultSet r = s.executeQuery("SELECT uuid,team_id FROM members")) {
            while (r.next()) { TeamData t = teams.get(UUID.fromString(r.getString(2))); if (t != null) t.members.add(UUID.fromString(r.getString(1))); }
        }
    }
    private TeamData teamOf(UUID id) { return teams.values().stream().filter(t -> t.members.contains(id)).findFirst().orElse(null); }
    private String tier(Stats s) {
        double ratio = s.deaths == 0 ? (s.kills > 0 ? 99.0 : 0.0) : (double)s.kills / s.deaths;
        var t = getConfig().getConfigurationSection("kd.tiers");
        if (t != null) for (String rank : List.of("S","A","B","C","D")) if (ratio >= t.getDouble(rank, Double.POSITIVE_INFINITY)) return rank;
        return "F";
    }
    private TextColor teamColor(TeamData t) {
        if (t == null || t.color == null) return NamedTextColor.WHITE;
        try { return TextColor.fromHexString(colors.getOrDefault(t.color, "#FFFFFF")); } catch (Exception e) { return NamedTextColor.WHITE; }
    }
    private Component playerName(Player p) { return Component.text(p.getName(), teamColor(teamOf(p.getUniqueId()))); }
    private Stats stats(UUID id, String name) throws SQLException {
        try (PreparedStatement q = db.prepareStatement("SELECT kills,deaths FROM stats WHERE uuid=?")) {
            q.setString(1,id.toString()); try (ResultSet r=q.executeQuery()) { if (r.next()) return new Stats(r.getInt(1),r.getInt(2)); }
        }
        try (PreparedStatement q=db.prepareStatement("INSERT OR IGNORE INTO stats(uuid,name) VALUES(?,?)")) { q.setString(1,id.toString()); q.setString(2,name); q.executeUpdate(); }
        return new Stats(0,0);
    }
    private void updateStat(Player p, String column) {
        try (PreparedStatement q=db.prepareStatement("INSERT INTO stats(uuid,name,"+column+") VALUES(?,?,1) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,"+column+"="+column+"+1")) {
            q.setString(1,p.getUniqueId().toString()); q.setString(2,p.getName()); q.executeUpdate();
        } catch (SQLException e) { getLogger().warning("Could not update K/D: "+e.getMessage()); }
    }
    private void refreshPlayer(Player p) {
        try {
            Stats s=stats(p.getUniqueId(),p.getName());
            // K/D suffix is deliberately only on the TAB player-list name.
            Component tab=playerName(p).append(Component.text(" ["+tier(s)+"]", tierColor(tier(s))));
            p.playerListName(tab);
            Scoreboard board=Bukkit.getScoreboardManager().getMainScoreboard();
            String entry=p.getName();
            String teamKey="furyfied_"+p.getUniqueId().toString().substring(0,8);
            Team sb=board.getTeam(teamKey); if(sb==null) sb=board.registerNewTeam(teamKey);
            sb.color(ChatColor.WHITE);
            if(!sb.hasEntry(entry)) sb.addEntry(entry);
        } catch(Exception e) { getLogger().warning("Could not refresh "+p.getName()+": "+e.getMessage()); }
    }
    private TextColor tierColor(String t) { return switch(t) { case "S"->TextColor.color(0xD6B84C); case "A"->TextColor.color(0x9149C9); case "B"->TextColor.color(0x528BCB); case "C"->TextColor.color(0x25894D); case "D"->TextColor.color(0xC85B43); default->TextColor.color(0xD0D0D0); }; }

    @EventHandler public void onJoin(PlayerJoinEvent e) { refreshPlayer(e.getPlayer()); }
    @EventHandler public void onDeath(PlayerDeathEvent e) {
        Player victim=e.getEntity(); updateStat(victim,"deaths");
        Player killer=victim.getKiller(); if(killer!=null) updateStat(killer,"kills");
        Bukkit.getScheduler().runTask(this,()->{ refreshPlayer(victim); if(killer!=null) refreshPlayer(killer); });
    }
    @EventHandler public void onChat(AsyncChatEvent e) {
        Player p=e.getPlayer();
        // Only the sender's name is team-colored; the message component is untouched.
        e.renderer((source, displayName, message, viewer) -> playerName(p).append(Component.text(": ", NamedTextColor.GRAY)).append(message));
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] a) {
        String root=command.getName().toLowerCase(Locale.ROOT);
        if(root.equals("team")) return teamCommand(sender,a);
        if(root.equals("kd")) return kdCommand(sender,a);
        if(!sender.hasPermission("furyfiedffa.admin")) { sender.sendMessage("No permission."); return true; }
        if(root.equals("teamadmin")) { sender.sendMessage("Admin team tools are reserved for the next implementation pass."); return true; }
        if(root.equals("kdadmin")) { sender.sendMessage("Admin K/D tools are reserved for the next implementation pass."); return true; }
        return true;
    }
    private boolean teamCommand(CommandSender sender,String[] a) {
        if(!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        if(a.length==0) { p.sendMessage("/team create <name>, invite <player>, accept, deny, leave, kick <player>, disband, info, list, chat, color [name]"); return true; }
        try {
            switch(a[0].toLowerCase(Locale.ROOT)) {
                case "create" -> {
                    if(a.length<2) { p.sendMessage("Usage: /team create <name>"); break; }
                    if(teamOf(p.getUniqueId())!=null) { p.sendMessage("You are already in a team."); break; }
                    String name=a[1]; UUID id=UUID.randomUUID();
                    try(PreparedStatement q=db.prepareStatement("INSERT INTO teams(id,name,leader,color) VALUES(?,?,?,NULL)")) {
                        q.setString(1,id.toString());q.setString(2,name);q.setString(3,p.getUniqueId().toString());q.executeUpdate();
                    }
                    TeamData t=new TeamData(id,name,p.getUniqueId(),null);t.members.add(p.getUniqueId());teams.put(id,t);p.sendMessage("Created team "+name+".");refreshAll();
                }
                case "invite" -> {
                    if(a.length<2) { p.sendMessage("Usage: /team invite <player>"); break; }
                    TeamData t=teamOf(p.getUniqueId()); Player target=Bukkit.getPlayerExact(a[1]);
                    if(t==null||!t.leader.equals(p.getUniqueId())) { p.sendMessage("Only your team leader can invite."); break; }
                    if(target==null||teamOf(target.getUniqueId())!=null) { p.sendMessage("Player unavailable or already in a team."); break; }
                    invites.put(target.getUniqueId(),t.id);target.sendMessage("Invited to "+t.name+". Use /team accept or /team deny.");p.sendMessage("Invitation sent.");
                }
                case "accept" -> {
                    UUID tid=invites.remove(p.getUniqueId());TeamData t=tid==null?null:teams.get(tid);
                    if(t==null) { p.sendMessage("No pending invitation.");break; }
                    if(t.members.size()>=getConfig().getInt("team.max-size",10)) { p.sendMessage("Team is full.");break; }
                    try(PreparedStatement q=db.prepareStatement("INSERT INTO members(uuid,team_id) VALUES(?,?)")){q.setString(1,p.getUniqueId().toString());q.setString(2,t.id.toString());q.executeUpdate();}
                    t.members.add(p.getUniqueId());p.sendMessage("Joined "+t.name+".");refreshAll();
                }
                case "deny" -> { invites.remove(p.getUniqueId());p.sendMessage("Invitation declined."); }
                case "leave" -> {
                    TeamData t=teamOf(p.getUniqueId());if(t==null){p.sendMessage("You are not in a team.");break;}
                    if(t.leader.equals(p.getUniqueId())){p.sendMessage("Leaders must use /team disband or transfer leadership.");break;}
                    removeMember(t,p.getUniqueId());p.sendMessage("You left "+t.name+".");refreshAll();
                }
                case "kick" -> {
                    TeamData t=teamOf(p.getUniqueId());Player target=a.length>1?Bukkit.getPlayerExact(a[1]):null;
                    if(t==null||!t.leader.equals(p.getUniqueId())||target==null||!t.members.contains(target.getUniqueId())||target.equals(p)){p.sendMessage("Usage: /team kick <online-member> (leader only)");break;}
                    removeMember(t,target.getUniqueId());target.sendMessage("You were removed from "+t.name+".");p.sendMessage("Member removed.");refreshAll();
                }
                case "disband" -> {
                    TeamData t=teamOf(p.getUniqueId());if(t==null||!t.leader.equals(p.getUniqueId())){p.sendMessage("Only your team leader can disband.");break;}
                    try(PreparedStatement q=db.prepareStatement("DELETE FROM teams WHERE id=?")){q.setString(1,t.id.toString());q.executeUpdate();}
                    teams.remove(t.id);p.sendMessage("Team disbanded.");refreshAll();
                }
                case "color" -> {
                    TeamData t=teamOf(p.getUniqueId());if(t==null||!t.leader.equals(p.getUniqueId())){p.sendMessage("Only a team leader can change color.");break;}
                    if(a.length<2){p.sendMessage("Available colors: "+String.join(", ",colors.keySet()));break;}
                    String c=a[1].toLowerCase(Locale.ROOT);if(!colors.containsKey(c)){p.sendMessage("Unknown color. Use /team color.");break;}
                    if(teams.values().stream().anyMatch(x->x!=t&&c.equals(x.color))){p.sendMessage("That color is already taken.");break;}
                    t.color=c;try(PreparedStatement q=db.prepareStatement("UPDATE teams SET color=? WHERE id=?")){q.setString(1,c);q.setString(2,t.id.toString());q.executeUpdate();}
                    p.sendMessage("Team color changed to "+c+".");refreshAll();
                }
                case "info" -> { TeamData t=teamOf(p.getUniqueId()); if(t==null) p.sendMessage(Component.text("You are not in a team.", NamedTextColor.RED)); else sendTeamInfo(p,t); }
                case "members" -> { TeamData t=teamOf(p.getUniqueId());p.sendMessage(t==null?"You are not in a team.":"Members: "+t.members.stream().map(id->Bukkit.getOfflinePlayer(id).getName()).toList()); }
                case "list" -> p.sendMessage("Teams: "+teams.values().stream().map(t->t.name).toList());
                case "chat" -> p.sendMessage("Team chat toggle is not yet implemented in this build.");
                default -> p.sendMessage("Unknown subcommand. Use /team.");
            }
        } catch(Exception ex) { p.sendMessage("Team operation failed: "+ex.getMessage()); getLogger().warning(ex.toString()); }
        return true;
    }
    private void sendTeamInfo(Player viewer,TeamData t) throws SQLException {
        TextColor c=teamColor(t);
        NamedTextColor gray=NamedTextColor.GRAY, dark=NamedTextColor.DARK_GRAY;
        Component bar=Component.text("\u2501".repeat(32),c);
        OfflinePlayer lead=Bukkit.getOfflinePlayer(t.leader);
        int online=0;
        for(UUID id:t.members) if(Bukkit.getPlayer(id)!=null) online++;
        int max=getConfig().getInt("team.max-size",10);
        Component out=Component.empty()
            .append(Component.text("\u2501".repeat(8)+" ",c))
            .append(Component.text("\u2694 TEAM INFO \u2694",c,TextDecoration.BOLD))
            .append(Component.text(" "+"\u2501".repeat(8),c))
            .append(Component.newline())
            .append(Component.text(" \u2726 Team: ",gray)).append(Component.text(t.name,c,TextDecoration.BOLD))
            .append(Component.newline())
            .append(Component.text(" \u265B Leader: ",gray)).append(Component.text(Objects.toString(lead.getName(),"Unknown"),NamedTextColor.WHITE))
            .append(Component.newline())
            .append(Component.text(" \u25CF Members: ",gray)).append(Component.text(t.members.size()+"/"+max,NamedTextColor.WHITE))
            .append(Component.text("  ("+online+" online)",dark))
            .append(Component.newline())
            .append(Component.text(" \u2736 Color: ",gray)).append(Component.text(t.color==null?"none":t.color,c))
            .append(Component.newline())
            .append(Component.text(" Roster",dark,TextDecoration.ITALIC));
        List<UUID> roster=new ArrayList<>(t.members);
        roster.sort(Comparator.comparing((UUID id)->!id.equals(t.leader)).thenComparing(id->Bukkit.getPlayer(id)==null).thenComparing(id->Objects.toString(Bukkit.getOfflinePlayer(id).getName(),"")));
        for(UUID id:roster) {
            OfflinePlayer op=Bukkit.getOfflinePlayer(id);
            String name=Objects.toString(op.getName(),"Unknown");
            boolean on=Bukkit.getPlayer(id)!=null;
            String tr=tier(stats(id,name));
            out=out.append(Component.newline())
                .append(Component.text("  \u25AA ",c))
                .append(Component.text(id.equals(t.leader)?"\u265B ":"",NamedTextColor.GOLD))
                .append(Component.text(name,on?NamedTextColor.WHITE:NamedTextColor.GRAY))
                .append(Component.text(" ["+tr+"]",tierColor(tr)))
                .append(Component.text(on?"  \u25CF online":"  \u25CB offline",on?NamedTextColor.GREEN:NamedTextColor.DARK_GRAY));
        }
        out=out.append(Component.newline()).append(bar);
        viewer.sendMessage(out);
    }
    private void removeMember(TeamData t,UUID id) throws SQLException {
        try(PreparedStatement q=db.prepareStatement("DELETE FROM members WHERE uuid=?")){q.setString(1,id.toString());q.executeUpdate();}
        t.members.remove(id);
    }
    private void refreshAll() { for(Player p:Bukkit.getOnlinePlayers()) refreshPlayer(p); }
    private boolean kdCommand(CommandSender sender,String[] a) {
        try {
            if(a.length==0||a[0].equalsIgnoreCase("stats")) {
                if(a.length>1) { OfflinePlayer op=Bukkit.getOfflinePlayer(a[1]); Stats s=stats(op.getUniqueId(),Objects.toString(op.getName(),a[1]));sender.sendMessage(a[1]+": "+s.kills+" kills, "+s.deaths+" deaths, "+ratio(s)+" K/D, tier "+tier(s)); }
                else if(sender instanceof Player p) { Stats s=stats(p.getUniqueId(),p.getName());sender.sendMessage("K/D: "+s.kills+" kills, "+s.deaths+" deaths, "+ratio(s)+" ratio, tier "+tier(s)); }
                else sender.sendMessage("Use /kd stats <player>.");
                return true;
            }
            if(a[0].equalsIgnoreCase("top")) {
                String sort=a.length>1?a[1].toLowerCase(Locale.ROOT):"ratio";
                if(!Set.of("ratio","kills","deaths").contains(sort)){sender.sendMessage("Usage: /kd top [ratio|kills|deaths]");return true;}
                String order=sort.equals("ratio")?"(CASE WHEN deaths=0 THEN kills*1.0 ELSE kills*1.0/deaths END) DESC":sort+" DESC";
                try(Statement q=db.createStatement();ResultSet r=q.executeQuery("SELECT name,kills,deaths FROM stats ORDER BY "+order+" LIMIT "+getConfig().getInt("kd.leaderboard-size",10))){
                    sender.sendMessage("§6§lTOP K/D "+sort.toUpperCase(Locale.ROOT));
                    int i=1;while(r.next()){Stats s=new Stats(r.getInt(2),r.getInt(3));sender.sendMessage("§e#"+i+++" §f"+r.getString(1)+" §7- §b"+(sort.equals("ratio")?ratio(s):sort.equals("kills")?s.kills:s.deaths));}
                } return true;
            }
            if(a[0].equalsIgnoreCase("rank")&&sender instanceof Player p){Stats s=stats(p.getUniqueId(),p.getName());sender.sendMessage("Your tier: "+tier(s));return true;}
        } catch(Exception e){sender.sendMessage("K/D query failed: "+e.getMessage());}
        sender.sendMessage("Usage: /kd [stats <player>|top [ratio|kills|deaths]|rank]");return true;
    }
    private String ratio(Stats s){return String.format(Locale.US,"%.2f",s.deaths==0?(s.kills>0?99.99:0.0):(double)s.kills/s.deaths);}
    @Override public List<String> onTabComplete(CommandSender s,Command c,String a,String[] args) {
        if(c.getName().equalsIgnoreCase("team")&&args.length==1)return List.of("create","invite","accept","deny","leave","kick","disband","info","members","list","chat","color");
        if(c.getName().equalsIgnoreCase("team")&&args.length==2&&args[0].equalsIgnoreCase("color"))return colors.keySet().stream().toList();
        if(c.getName().equalsIgnoreCase("kd")&&args.length==1)return List.of("stats","top","rank");
        if(c.getName().equalsIgnoreCase("kd")&&args.length==2&&args[0].equalsIgnoreCase("top"))return List.of("ratio","kills","deaths");
        return List.of();
    }
    private record Stats(int kills,int deaths) {}
    private static final class TeamData {
        final UUID id,leader; final String name; String color; final Set<UUID> members=new HashSet<>();
        TeamData(UUID id,String name,UUID leader,String color){this.id=id;this.name=name;this.leader=leader;this.color=color;members.add(leader);}
    }
}
