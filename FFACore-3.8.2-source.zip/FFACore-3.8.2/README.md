# FFACore 3.8.2 — source build

Author: HeyItsLyu  
Target: Paper 1.21.11 and Leaf 1.21.11  
Java: 21

## Build
Install JDK 21 and Maven 3.9+, then run:

    mvn clean package

The plugin JAR will be created in `target/FFACore-3.8.2.jar`.

## Current implementation status
This is an initial source build, not a release-tested commercial JAR. It includes SQLite-backed K/D counters, `/kd stats`, `/kd top [ratio|kills|deaths]`, `/kd rank`, basic team creation/invites/accept/leave/kick/disband/info/list/color, exclusive configured team colors, colored sender names in chat, and TAB-only K/D suffixes.

Before selling, compile against the exact Paper 1.21.11 API and test on Paper and Leaf 1.21.11. Nametag color behavior depends on scoreboard-team color support and client/server behavior; this initial build uses scoreboard team color and may need integration testing with TAB or other scoreboard plugins.

Not implemented in this initial build: team chat toggle, promote/demote, wins/team leaderboards, admin mutation commands, full placeholder/TAB plugin integration, robust team rename/transfer, and reload-safe live leaderboard caching. Do not advertise these as working yet.
