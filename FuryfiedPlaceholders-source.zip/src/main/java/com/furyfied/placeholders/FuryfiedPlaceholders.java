package com.furyfied.placeholders;

import org.bukkit.plugin.java.JavaPlugin;

public class FuryfiedPlaceholders extends JavaPlugin {
    @Override
    public void onEnable() {
        FuryExpansion expansion = new FuryExpansion(this);
        if (!expansion.isReady()) {
            getLogger().severe("Could not hook into FuryfiedFFA. Disabling.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        expansion.register();
        getLogger().info("Registered %furyfied_...% placeholders.");
    }
}
