package com.furyfied.placeholders;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Placeholders (identifier "furyfied"):
 *   %furyfied_team_color%  -> &#RRGGBB of the player's team (or &f if none)
 *   %furyfied_team_name%   -> team name (or empty)
 *   %furyfied_tier%        -> S / A / B / C / D / F
 *   %furyfied_kills%  %furyfied_deaths%  %furyfied_kd%
 *
 * It reads FuryfiedFFA through reflection, so FuryfiedFFA itself is not modified.
 */
public class FuryExpansion extends PlaceholderExpansion {
    private final FuryfiedPlaceholders self;
    private final Plugin ffa;

    private Method teamOf;   // teamOf(UUID) -> TeamData
    private Method stats;    // stats(UUID, String) -> Stats
    private Method tier;     // tier(Stats) -> String
    private Field colorsField; // Map<String,String> name -> hex
    private Field teamName;
    private Field teamColor;
    private Method kills;
    private Method deaths;

    private record Snapshot(long time, String color, String name, String tier, int kills, int deaths) {}
    private final Map<UUID, Snapshot> cache = new ConcurrentHashMap<>();
    private static final long CACHE_MS = 3000;

    public FuryExpansion(FuryfiedPlaceholders self) {
        this.self = self;
        this.ffa = Bukkit.getPluginManager().getPlugin("FuryfiedFFA");
        try {
            if (ffa == null) return;
            Class<?> c = ffa.getClass();
            teamOf = find(c, "teamOf", 1);
            stats = find(c, "stats", 2);
            tier = find(c, "tier", 1);
            colorsField = c.getDeclaredField("colors");
            colorsField.setAccessible(true);

            Class<?> teamData = Class.forName(c.getName() + "$TeamData", true, c.getClassLoader());
            teamName = teamData.getDeclaredField("name");
            teamName.setAccessible(true);
            teamColor = teamData.getDeclaredField("color");
            teamColor.setAccessible(true);

            Class<?> statsCls = Class.forName(c.getName() + "$Stats", true, c.getClassLoader());
            kills = statsCls.getDeclaredMethod("kills");
            kills.setAccessible(true);
            deaths = statsCls.getDeclaredMethod("deaths");
            deaths.setAccessible(true);
        } catch (Throwable t) {
            self.getLogger().severe("Reflection setup failed: " + t);
            teamOf = null;
        }
    }

    private static Method find(Class<?> c, String name, int params) throws NoSuchMethodException {
        for (Method m : c.getDeclaredMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == params) {
                m.setAccessible(true);
                return m;
            }
        }
        throw new NoSuchMethodException(name);
    }

    public boolean isReady() { return ffa != null && teamOf != null && stats != null && tier != null; }

    private Snapshot snapshot(OfflinePlayer p) {
        UUID id = p.getUniqueId();
        Snapshot old = cache.get(id);
        long now = System.currentTimeMillis();
        if (old != null && now - old.time() < CACHE_MS) return old;
        String color = "&f", name = "", tierName = "F";
        int k = 0, d = 0;
        try {
            Object team = teamOf.invoke(ffa, id);
            if (team != null) {
                name = String.valueOf(teamName.get(team));
                Object key = teamColor.get(team);
                if (key != null) {
                    @SuppressWarnings("unchecked")
                    Map<String, String> colors = (Map<String, String>) colorsField.get(ffa);
                    String hex = colors.get(String.valueOf(key).toLowerCase(Locale.ROOT));
                    if (hex != null) color = "&" + (hex.startsWith("#") ? hex : "#" + hex);
                }
            }
            Object st = stats.invoke(ffa, id, p.getName() == null ? "unknown" : p.getName());
            if (st != null) {
                tierName = String.valueOf(tier.invoke(ffa, st));
                k = (int) kills.invoke(st);
                d = (int) deaths.invoke(st);
            }
        } catch (Throwable t) {
            if (old != null) return old;
        }
        Snapshot s = new Snapshot(now, color, name, tierName, k, d);
        cache.put(id, s);
        return s;
    }

    @Override public @NotNull String getIdentifier() { return "furyfied"; }
    @Override public @NotNull String getAuthor() { return "HeyItsLyu"; }
    @Override public @NotNull String getVersion() { return self.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "";
        Snapshot s = snapshot(player);
        switch (params.toLowerCase(Locale.ROOT)) {
            case "team_color": return s.color();
            case "team_name": return s.name();
            case "tier": return s.tier();
            case "kills": return String.valueOf(s.kills());
            case "deaths": return String.valueOf(s.deaths());
            case "kd": return String.format(Locale.US, "%.2f",
                    s.deaths() == 0 ? (double) s.kills() : (double) s.kills() / s.deaths());
            default: return null;
        }
    }
}
